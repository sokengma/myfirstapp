
public class Person {
	
	private String name;
	private int jahr;
	
	
	public Person (){
	
	}
	public Person(String name, int jahr){
		this.name=name;
		this.jahr=jahr;
	}
	
	public String toString() {
		return "Person [name=" + name + ", jahr=" + jahr + "]";
	}



}
