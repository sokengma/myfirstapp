
public class Satz {
	public static void main(String[]args){}
	
	 String satz = "hallo";
	
	
	public static void zaehleZeichen(String satz){
		satz="hallo";
		String i = satz;
	int k= Integer.valueOf(i).intValue()	;
	System.out.println(k);
	}

}
