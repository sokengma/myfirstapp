
public class TestStudent {
	
	public static void main(String []args){
		
		Student std = new Student("henry", 1992, 20161236);
		
		System.out.println(std.toString());
		System.out.println(std.name);
		System.out.println(std.jahr);
	}

}
