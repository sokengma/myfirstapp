
public class Student extends Person {
	
	public String name;
	public int jahr;
	public int matrikel;
	
	public Student() {
		
		super();
		
	}
	
	public Student (String name, int jahr, int matrikel){
		super(name, jahr);
		this.matrikel=matrikel;
	}





public String toString() {
		
		return super.toString();
				//"Student : matrikel=" + matrikel + " " + name + jahr;
	}

}
